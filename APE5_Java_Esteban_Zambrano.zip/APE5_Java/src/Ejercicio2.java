import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        try {
            System.out.print("Ingrese un mensaje: ");
            String mensaje = entrada.nextLine();

            FileWriter escritor = new FileWriter("estudiantes.txt", true);
            escritor.write(mensaje + System.lineSeparator());
            escritor.close();

            System.out.println("La información se guardó correctamente.");

        } catch (IOException e) {
            System.out.println("Error al escribir: " + e.getMessage());
        }

        entrada.close();
    }
}
