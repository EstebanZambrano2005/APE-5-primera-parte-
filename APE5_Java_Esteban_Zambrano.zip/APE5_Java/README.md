# APE 5 – Manejo de archivos en Java

**Estudiante:** Esteban Zambrano  
**Carrera:** Ingeniería en Software  
**Universidad:** Universidad Técnica de Ambato  
**Actividad:** APE 5 – Primera parte

## Descripción

Desarrollo de tres ejercicios prácticos en Java relacionados con el manejo de archivos de texto.

## Ejercicios realizados

### Ejercicio 1: Crear un fichero
- Crear el archivo `curso.txt`.
- Comprobar si el archivo se creó o si ya existe.
- Mostrar el nombre del archivo mediante `getName()`.
- Controlar posibles errores con `try-catch`.

### Ejercicio 2: Escribir información en un fichero
- Ingresar un mensaje mediante `Scanner`.
- Utilizar `FileWriter` para escribir en `estudiantes.txt`.
- Utilizar el parámetro `true` para conservar el contenido anterior y agregar el nuevo mensaje al final.
- Guardar la información mediante `write()` y cerrar el archivo con `close()`.
- Controlar posibles errores con `try-catch`.

**Nota:** El archivo `estudiantes.txt` debe existir previamente. Se incluye un archivo vacío con ese nombre en esta entrega.

### Ejercicio 3: Eliminar un fichero
- Crear un objeto `File` para `estudiantes.txt`.
- Utilizar el método `delete()`.
- Comprobar si la eliminación se realizó correctamente.
- Mostrar un mensaje según el resultado.

## Herramientas y clases utilizadas

- Lenguaje de programación Java.
- `File`
- `IOException`
- `Scanner`
- `FileWriter`
- `createNewFile()`
- `getName()`
- `write()`
- `close()`
- `delete()`
- `try-catch`

## Objetivo

Aplicar los conocimientos de programación en Java mediante la creación, escritura y eliminación de archivos de texto, utilizando clases, métodos y manejo de excepciones.

## Ejecución

Los tres programas están en la carpeta `src` y deben ejecutarse por separado.

1. Ejecutar `Ejercicio1.java` para crear `curso.txt`.
2. Ejecutar `Ejercicio2.java` para ingresar y guardar un mensaje en `estudiantes.txt`.
3. Ejecutar `Ejercicio3.java` para eliminar `estudiantes.txt`.

Ejecutar los programas desde la carpeta principal del proyecto para que los archivos de texto se creen o encuentren en esa ubicación. El ejercicio 3 elimina `estudiantes.txt`, por lo que debe ejecutarse después de probar el ejercicio 2.
